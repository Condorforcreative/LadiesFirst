# Ladies First Shop

Hosted on GitHub Pages. Simple e-commerce shop with catalog and checkout.